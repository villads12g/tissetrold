package com.example.demo9;

public class Launcher {
    public static void main(String[] args) {
        ProjectGroupApp.main(args);
    }
}