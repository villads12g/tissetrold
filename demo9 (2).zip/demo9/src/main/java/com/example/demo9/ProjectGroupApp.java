package com.example.demo9;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

public class ProjectGroupApp extends Application {

    private ListView<String> activitiesList = new ListView<>();
    private ComboBox<String> projectDropdown = new ComboBox<>();
    private ComboBox<String> groupDropdown = new ComboBox<>();
    private TextArea groupDetails = new TextArea();

    private Map<String, String> groups = new HashMap<>();

    @Override
    public void start(Stage stage) {

        // LEFT PANEL
        VBox leftPanel = new VBox(10);
        leftPanel.setPadding(new Insets(10));

        TextField studentName = new TextField();
        studentName.setPromptText("Student name");

        projectDropdown.getItems().addAll(
                "Basic Project 1 in Natural Science",
                "Basic Project 2 in Natural Science",
                "Basic Project 3 in Natural Science",
                "Subject Module in Computer Science",
                "Bachelor Project in Natural Science"
        );

        Button signupBtn = new Button("Signup");

        signupBtn.setMaxWidth(Double.MAX_VALUE);

        signupBtn.setOnAction(e -> {
            String selected = projectDropdown.getValue();
            if (selected != null) {
                activitiesList.getItems().add(selected);
            }
        });

        activitiesList.setPrefHeight(200);

        leftPanel.getChildren().addAll(
                new Label("Student name"),
                studentName,
                new Label("Project"),
                projectDropdown,
                signupBtn,
                new Label("Signed up for activities"),
                activitiesList
        );

        // RIGHT PANEL
        VBox rightPanel = new VBox(10);
        rightPanel.setPadding(new Insets(10));

        TextField titleField = new TextField();
        TextField supervisorField = new TextField();

        Button createGroupBtn = new Button("Create project group");
        createGroupBtn.setMaxWidth(Double.MAX_VALUE);

        createGroupBtn.setOnAction(e -> {
            String title = titleField.getText();
            String supervisor = supervisorField.getText();

            if (!title.isEmpty()) {
                groups.put(title, "Supervisor: " + supervisor);
                groupDropdown.getItems().add(title);
            }
        });

        groupDropdown.setPromptText("Select group");

        Button joinGroupBtn = new Button("Join group");

        joinGroupBtn.setOnAction(e -> {
            String group = groupDropdown.getValue();
            String student = studentName.getText();

            if (group != null && student != null) {
                String info = group + "\n" +
                        groups.get(group) + "\n" +
                        "Members:\n" + student;

                groupDetails.setText(info);
            }
        });

        groupDetails.setPrefHeight(200);

        rightPanel.getChildren().addAll(
                new Label("Create new project group"),
                new Label("title"),
                titleField,
                new Label("supervisor"),
                supervisorField,
                createGroupBtn,
                new Label("or"),
                new Label("Add yourself to existing project group"),
                groupDropdown,
                joinGroupBtn,
                new Label("Selected project group"),
                groupDetails
        );

        // MAIN LAYOUT
        HBox root = new HBox(20);
        root.setPadding(new Insets(15));

        leftPanel.setPrefWidth(300);
        rightPanel.setPrefWidth(300);

        root.getChildren().addAll(leftPanel, rightPanel);

        Scene scene = new Scene(root, 650, 500);
        stage.setTitle("Project Group Management System");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}